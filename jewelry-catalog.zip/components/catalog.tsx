"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingBag, Eye, Filter, Star } from "lucide-react"
import { ProductModal } from "./product-modal"

interface CatalogProps {
  surveyResults: any
}

// Datos de ejemplo de joyas
const jewelryData = [
  {
    id: 1,
    name: "Anillo Solitario Diamante",
    collection: "Radiante",
    price: 15000,
    image: "/luxury-diamond-solitaire-ring-elegant-jewelry.jpg",
    category: "rings",
    style: "classic",
    mood: "radiant",
    occasion: "special",
    rating: 4.9,
    description: "Anillo solitario con diamante de 1 quilate, perfecto para brillar en cualquier ocasión",
  },
  {
    id: 2,
    name: "Collar Perlas Akoya",
    collection: "Serena",
    price: 8500,
    image: "/luxury-akoya-pearl-necklace-elegant-jewelry.jpg",
    category: "necklaces",
    style: "classic",
    mood: "serene",
    occasion: "special",
    rating: 4.8,
    description: "Collar de perlas Akoya que transmite paz y elegancia natural",
  },
  {
    id: 3,
    name: "Aretes Colgantes Esmeralda",
    collection: "Empoderada",
    price: 12000,
    image: "/luxury-emerald-drop-earrings-elegant-jewelry.jpg",
    category: "earrings",
    style: "vintage",
    mood: "empowered",
    occasion: "special",
    rating: 4.7,
    description: "Aretes colgantes con esmeraldas que reflejan tu fuerza interior",
  },
  {
    id: 4,
    name: "Pulsera Tenis Diamantes",
    collection: "Radiante",
    price: 25000,
    image: "/luxury-diamond-tennis-bracelet-elegant-jewelry.jpg",
    category: "bracelets",
    style: "modern",
    mood: "radiant",
    occasion: "special",
    rating: 5.0,
    description: "Pulsera tenis con diamantes para cuando quieres brillar intensamente",
  },
  {
    id: 5,
    name: "Anillo Vintage Zafiro",
    collection: "Serena",
    price: 6500,
    image: "/vintage-sapphire-ring-elegant-jewelry.jpg",
    category: "rings",
    style: "vintage",
    mood: "serene",
    occasion: "daily",
    rating: 4.6,
    description: "Anillo vintage con zafiro azul que aporta calma y sofisticación",
  },
  {
    id: 6,
    name: "Collar Minimalista Oro",
    collection: "Gentil",
    price: 2800,
    image: "/minimalist-gold-necklace-elegant-jewelry.jpg",
    category: "necklaces",
    style: "modern",
    mood: "gentle",
    occasion: "daily",
    rating: 4.5,
    description: "Collar minimalista que te abraza suavemente en días difíciles",
  },
  {
    id: 7,
    name: "Aretes Bohemios Turquesa",
    collection: "Empoderada",
    price: 1200,
    image: "/bohemian-turquoise-earrings-elegant-jewelry.jpg",
    category: "earrings",
    style: "bohemian",
    mood: "empowered",
    occasion: "daily",
    rating: 4.4,
    description: "Aretes bohemios que celebran tu espíritu libre y poderoso",
  },
  {
    id: 8,
    name: "Pulsera Charm Personalizada",
    collection: "Gentil",
    price: 3500,
    image: "/personalized-charm-bracelet-elegant-jewelry.jpg",
    category: "bracelets",
    style: "modern",
    mood: "gentle",
    occasion: "gift",
    rating: 4.8,
    description: "Pulsera de charms personalizable que cuenta tu historia única",
  },
]

export function Catalog({ surveyResults }: CatalogProps) {
  const [favorites, setFavorites] = useState<number[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  // Filtrar joyas basado en las respuestas del survey
  const recommendedJewelry = useMemo(() => {
    return jewelryData
      .filter((item) => {
        // Filtrar por categoría si está seleccionada
        if (selectedCategory !== "all") {
          const categoryMap: Record<string, string> = {
            rings: "rings",
            necklaces: "necklaces",
            earrings: "earrings",
            bracelets: "bracelets",
          }
          if (item.category !== categoryMap[selectedCategory]) return false
        }

        // Puntuación basada en las respuestas del survey
        let score = 0
        if (item.style === surveyResults.style) score += 3
        if (item.mood === surveyResults.mood) score += 3 // usar mood en lugar de metal
        if (item.occasion === surveyResults.occasion) score += 2

        // Filtro por presupuesto
        const budgetRanges: Record<string, [number, number]> = {
          entry: [500, 2000],
          mid: [2000, 10000],
          luxury: [10000, 50000],
          exclusive: [50000, Number.POSITIVE_INFINITY],
        }
        const [min, max] = budgetRanges[surveyResults.budget] || [0, Number.POSITIVE_INFINITY]
        if (item.price < min || item.price > max) return false

        return score > 0
      })
      .sort((a, b) => {
        // Ordenar por relevancia (más matches primero)
        let scoreA = 0,
          scoreB = 0
        if (a.style === surveyResults.style) scoreA += 3
        if (a.mood === surveyResults.mood) scoreA += 3 // usar mood en lugar de metal
        if (a.occasion === surveyResults.occasion) scoreA += 2
        if (b.style === surveyResults.style) scoreB += 3
        if (b.mood === surveyResults.mood) scoreB += 3 // usar mood en lugar de metal
        if (b.occasion === surveyResults.occasion) scoreB += 2
        return scoreB - scoreA
      })
  }, [surveyResults, selectedCategory])

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => (prev.includes(id) ? prev.filter((fav) => fav !== id) : [...prev, id]))
  }

  const openProductModal = (product: any) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  const categories = [
    { id: "all", label: "Todas", count: recommendedJewelry.length },
    { id: "rings", label: "Anillos", count: recommendedJewelry.filter((item) => item.category === "rings").length },
    {
      id: "necklaces",
      label: "Collares",
      count: recommendedJewelry.filter((item) => item.category === "necklaces").length,
    },
    {
      id: "earrings",
      label: "Aretes",
      count: recommendedJewelry.filter((item) => item.category === "earrings").length,
    },
    {
      id: "bracelets",
      label: "Pulseras",
      count: recommendedJewelry.filter((item) => item.category === "bracelets").length,
    },
  ]

  return (
    <section className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold mb-4">Tu Colección Personalizada</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Basado en tus preferencias, hemos seleccionado estas piezas únicas especialmente para ti
        </p>
      </div>

      {/* Filtros */}
      <div className="flex flex-wrap gap-2 mb-8 justify-center">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? "default" : "outline"}
            onClick={() => setSelectedCategory(category.id)}
            className="gap-2"
          >
            <Filter className="h-4 w-4" />
            {category.label}
            <Badge variant="secondary" className="ml-1">
              {category.count}
            </Badge>
          </Button>
        ))}
      </div>

      {/* Grid de productos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {recommendedJewelry.map((item, index) => (
          <Card key={item.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
            <div className="relative aspect-square overflow-hidden">
              <img
                src={item.image || "/placeholder.svg"}
                alt={item.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              {/* Badges */}
              <div className="absolute top-3 left-3 flex gap-2">
                {index < 3 && <Badge className="bg-primary text-primary-foreground">Recomendado</Badge>}
              </div>

              {/* Botones de acción */}
              <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Button size="sm" variant="secondary" className="h-8 w-8 p-0" onClick={() => toggleFavorite(item.id)}>
                  <Heart className={`h-4 w-4 ${favorites.includes(item.id) ? "fill-red-500 text-red-500" : ""}`} />
                </Button>
                <Button size="sm" variant="secondary" className="h-8 w-8 p-0" onClick={() => openProductModal(item)}>
                  <Eye className="h-4 w-4" />
                </Button>
              </div>

              {/* Botón de compra */}
              <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Button className="w-full gap-2" onClick={() => openProductModal(item)}>
                  <ShoppingBag className="h-4 w-4" />
                  Ver Detalles
                </Button>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-center gap-1 mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-3 w-3 ${
                      i < Math.floor(item.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
                <span className="text-xs text-muted-foreground ml-1">({item.rating})</span>
              </div>

              <h3 className="font-semibold text-lg mb-1 text-balance">{item.name}</h3>
              <p className="text-sm text-muted-foreground mb-2">{item.collection}</p>
              <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{item.description}</p>

              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-primary">${item.price.toLocaleString()}</span>
                <div className="flex gap-1">
                  <Badge variant="outline" className="text-xs">
                    {item.style}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {item.collection}
                  </Badge>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {recommendedJewelry.length === 0 && (
        <div className="text-center py-12">
          <p className="text-lg text-muted-foreground">
            No encontramos joyas que coincidan con tus preferencias en esta categoría.
          </p>
          <Button variant="outline" onClick={() => setSelectedCategory("all")} className="mt-4">
            Ver todas las joyas
          </Button>
        </div>
      )}

      <ProductModal product={selectedProduct} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </section>
  )
}
