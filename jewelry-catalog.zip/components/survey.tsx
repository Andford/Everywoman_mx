"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ChevronRight, Heart, Crown, Sparkles, Star, Diamond, Gem, Sun, Zap, Cloud } from "lucide-react"

interface SurveyProps {
  onComplete: (results: any) => void
}

const questions = [
  {
    id: "occasion",
    title: "¿Para qué ocasión buscas joyería?",
    options: [
      { id: "daily", label: "Uso diario", icon: Heart, description: "Piezas versátiles y cómodas" },
      { id: "special", label: "Ocasiones especiales", icon: Crown, description: "Eventos importantes y celebraciones" },
      { id: "gift", label: "Regalo", icon: Sparkles, description: "Para alguien especial" },
      { id: "collection", label: "Colección personal", icon: Star, description: "Inversión y coleccionismo" },
    ],
  },
  {
    id: "style",
    title: "¿Cuál es tu estilo preferido?",
    options: [
      { id: "classic", label: "Clásico", icon: Crown, description: "Elegante y atemporal" },
      { id: "modern", label: "Moderno", icon: Diamond, description: "Líneas limpias y contemporáneo" },
      { id: "vintage", label: "Vintage", icon: Gem, description: "Con historia y carácter" },
      { id: "bohemian", label: "Bohemio", icon: Heart, description: "Libre y artístico" },
    ],
  },
  {
    id: "mood",
    title: "¿Cómo te sientes hoy?",
    options: [
      {
        id: "radiant",
        label: "Muy de buenas",
        icon: Sun,
        description: "Energética y brillante, lista para conquistar el mundo",
      },
      { id: "serene", label: "Serena", icon: Cloud, description: "Tranquila y en paz, buscando armonía" },
      {
        id: "empowered",
        label: "Empoderada",
        icon: Zap,
        description: "Fuerte y decidida, necesitas algo que refleje tu poder",
      },
      {
        id: "gentle",
        label: "No en mis mejores días",
        icon: Heart,
        description: "Necesitas algo que te haga sentir mejor y más segura",
      },
    ],
  },
  {
    id: "budget",
    title: "¿Cuál es tu rango de presupuesto?",
    options: [
      { id: "entry", label: "$500 - $2,000", icon: Heart, description: "Piezas accesibles de calidad" },
      { id: "mid", label: "$2,000 - $10,000", icon: Star, description: "Joyería premium" },
      { id: "luxury", label: "$10,000 - $50,000", icon: Crown, description: "Alta joyería" },
      { id: "exclusive", label: "$50,000+", icon: Diamond, description: "Piezas exclusivas y únicas" },
    ],
  },
]

export function Survey({ onComplete }: SurveyProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})

  const handleAnswer = (questionId: string, answerId: string) => {
    const newAnswers = { ...answers, [questionId]: answerId }
    setAnswers(newAnswers)

    if (currentQuestion < questions.length - 1) {
      setTimeout(() => {
        setCurrentQuestion(currentQuestion + 1)
      }, 300)
    } else {
      setTimeout(() => {
        onComplete(newAnswers)
      }, 300)
    }
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100
  const question = questions[currentQuestion]

  return (
    <section className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto">
        {/* Header del survey */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Encuentra tu Estilo Perfecto</h2>
          <p className="text-muted-foreground mb-6">
            Responde algunas preguntas para descubrir las joyas ideales para ti
          </p>
          <div className="space-y-2">
            <Progress value={progress} className="h-2" />
            <p className="text-sm text-muted-foreground">
              Pregunta {currentQuestion + 1} de {questions.length}
            </p>
          </div>
        </div>

        {/* Pregunta actual */}
        <Card className="p-8">
          <h3 className="text-2xl font-semibold mb-8 text-center text-balance">{question.title}</h3>

          <div className="grid gap-4">
            {question.options.map((option) => {
              const Icon = option.icon
              return (
                <Button
                  key={option.id}
                  variant="outline"
                  className="h-auto p-6 justify-start hover:bg-primary/5 hover:border-primary/50 transition-all duration-200 bg-transparent"
                  onClick={() => handleAnswer(question.id, option.id)}
                >
                  <div className="flex items-center gap-4 w-full">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 text-left">
                      <div className="font-semibold text-lg">{option.label}</div>
                      <div className="text-sm text-muted-foreground">{option.description}</div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </Button>
              )
            })}
          </div>
        </Card>
      </div>
    </section>
  )
}
