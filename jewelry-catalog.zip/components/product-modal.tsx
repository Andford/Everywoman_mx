"use client"

import { useState } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingBag, Star } from "lucide-react"

interface ProductModalProps {
  product: any
  isOpen: boolean
  onClose: () => void
}

export function ProductModal({ product, isOpen, onClose }: ProductModalProps) {
  const [isFavorite, setIsFavorite] = useState(false)

  if (!product) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-0">
        <div className="grid md:grid-cols-2 gap-0">
          {/* Imagen del producto */}
          <div className="relative aspect-square bg-gray-50">
            <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-full object-cover" />
            <Button
              size="sm"
              variant="secondary"
              className="absolute top-4 right-4 h-8 w-8 p-0"
              onClick={() => setIsFavorite(!isFavorite)}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
            </Button>
          </div>

          {/* Información del producto */}
          <div className="p-8 flex flex-col justify-between">
            <div>
              <div className="mb-4">
                <Badge variant="outline" className="mb-2">
                  {product.collection}
                </Badge>
                <h2 className="text-3xl font-bold mb-2">{product.name}</h2>
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="text-sm text-muted-foreground ml-2">({product.rating})</span>
                </div>
              </div>

              <div className="mb-6">
                <p className="text-4xl font-bold text-primary mb-2">${product.price.toLocaleString()}</p>
                <p className="text-muted-foreground leading-relaxed">{product.description}</p>
              </div>

              <div className="mb-6">
                <h3 className="font-semibold mb-3">Características:</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Colección:</span>
                    <span className="font-medium">{product.collection}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Estilo:</span>
                    <span className="font-medium capitalize">{product.style}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Categoría:</span>
                    <span className="font-medium capitalize">{product.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Ocasión:</span>
                    <span className="font-medium capitalize">{product.occasion}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Button className="w-full gap-2" size="lg">
                <ShoppingBag className="h-5 w-5" />
                Agregar al Carrito
              </Button>
              <Button variant="outline" className="w-full bg-transparent" size="lg">
                Consultar Disponibilidad
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
