"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Sparkles, Heart, Crown, Star } from "lucide-react"

interface HeroProps {
  onStartSurvey: () => void
}

export function Hero({ onStartSurvey }: HeroProps) {
  return (
    <section className="relative overflow-hidden">
      {/* Hero principal */}
      <div className="container mx-auto px-4 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-balance leading-tight">
                Descubre tu
                <span className="text-primary block">Colección Ideal</span>
              </h1>
              <p className="text-lg text-muted-foreground text-pretty max-w-md">
                Encuentra las joyas perfectas para ti con nuestro cuestionario personalizado. Cada pieza cuenta una
                historia única.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" onClick={onStartSurvey} className="text-lg px-8 py-6 bg-primary hover:bg-primary/90">
                <Sparkles className="mr-2 h-5 w-5" />
                Comenzar Cuestionario
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                Ver Catálogo Completo
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-6 float" style={{ animationDelay: "0s" }}>
                <div className="aspect-square bg-muted rounded-lg mb-4 relative overflow-hidden">
                  <img
                    src="/elegant-diamond-ring-luxury-jewelry.jpg"
                    alt="Anillo de diamante elegante"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
                <div className="flex items-center gap-2">
                  <Crown className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Anillos</span>
                </div>
              </Card>

              <Card className="p-6 float mt-8" style={{ animationDelay: "1s" }}>
                <div className="aspect-square bg-muted rounded-lg mb-4 relative overflow-hidden">
                  <img
                    src="/luxury-pearl-necklace-elegant-jewelry.jpg"
                    alt="Collar de perlas de lujo"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Collares</span>
                </div>
              </Card>

              <Card className="p-6 float -mt-4" style={{ animationDelay: "2s" }}>
                <div className="aspect-square bg-muted rounded-lg mb-4 relative overflow-hidden">
                  <img
                    src="/luxury-gold-earrings-elegant-jewelry.jpg"
                    alt="Aretes de oro de lujo"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Aretes</span>
                </div>
              </Card>

              <Card className="p-6 float mt-4" style={{ animationDelay: "0.5s" }}>
                <div className="aspect-square bg-muted rounded-lg mb-4 relative overflow-hidden">
                  <img
                    src="/luxury-gold-bracelet-elegant-jewelry.jpg"
                    alt="Pulsera de oro de lujo"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Pulseras</span>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Elementos decorativos */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-primary/5 rounded-full blur-xl" />
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-secondary/5 rounded-full blur-xl" />
    </section>
  )
}
