"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingBag } from "lucide-react"

export function FeaturedProduct() {
  return (
    <section className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        {/* Header inspirado en la imagen */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 text-balance">PARA CADA VERSIÓN DE TI</h2>
          <p className="text-lg text-muted-foreground">Descubre piezas únicas que reflejan tu personalidad</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Producto destacado - estilo similar a la imagen */}
          <div className="bg-white rounded-lg overflow-hidden shadow-lg">
            <div className="relative aspect-square bg-black p-8">
              <img
                src="/luxury-pearl-earrings-elegant-jewelry.jpg"
                alt="Aretes BILLIE HOLIDAY"
                className="w-full h-full object-contain"
              />
            </div>

            <div className="p-6">
              <div className="mb-4">
                <h3 className="text-2xl font-bold mb-2">BILLIE HOLIDAY</h3>
                <p className="text-3xl font-bold text-primary mb-3">PRECIO: $ 100.00</p>

                <div className="flex gap-2 mb-4">
                  <Badge variant="outline">Emotiva</Badge>
                  <Badge variant="outline">Única</Badge>
                  <Badge variant="outline">Pasional</Badge>
                </div>

                <p className="text-muted-foreground mb-2 italic">Aretes de acero inoxidable con perlas de río</p>
                <p className="text-sm text-muted-foreground">Tamaño pequeño</p>
              </div>

              <div className="flex gap-3">
                <Button className="flex-1 gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  Agregar al Carrito
                </Button>
                <Button variant="outline" size="icon">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Collage inspirado en la imagen */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4 mb-6">
              <img
                src="/vintage-woman-portrait-1.jpg"
                alt="Vintage portrait"
                className="aspect-square object-cover rounded-lg grayscale"
              />
              <img
                src="/vintage-woman-portrait-2.jpg"
                alt="Vintage portrait"
                className="aspect-square object-cover rounded-lg grayscale"
              />
              <img
                src="/vintage-woman-portrait-3.jpg"
                alt="Vintage portrait"
                className="aspect-square object-cover rounded-lg grayscale"
              />
              <img
                src="/vintage-woman-portrait-4.jpg"
                alt="Vintage portrait"
                className="aspect-square object-cover rounded-lg grayscale"
              />
            </div>

            <div className="text-center">
              <blockquote className="text-lg italic mb-4 text-balance">
                "Si voy a cantar como alguien más, entonces mejor no canto."
              </blockquote>
              <cite className="text-sm font-medium">- Billie Holiday</cite>
            </div>

            <div className="absolute bottom-0 right-0 bg-pink-400 text-white px-4 py-2 rounded-tl-lg">
              <span className="text-sm font-medium">@everywoman_mx</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
