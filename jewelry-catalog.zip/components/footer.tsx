import { Gem, Instagram, Facebook, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-muted/30 border-t border-border/40 mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo y descripción */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Gem className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Everywoman</h3>
                <p className="text-xs text-muted-foreground">Joyería con significado</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Creamos joyas únicas que cuentan historias extraordinarias. Cada pieza es una obra de arte diseñada para
              durar toda la vida.
            </p>
          </div>

          {/* Enlaces rápidos */}
          <div>
            <h4 className="font-semibold mb-4">Colecciones</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Anillos
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Collares
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Aretes
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Pulseras
                </a>
              </li>
            </ul>
          </div>

          {/* Servicios */}
          <div>
            <h4 className="font-semibold mb-4">Servicios</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Diseño Personalizado
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Reparaciones
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Certificación
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground transition-colors">
                  Garantía
                </a>
              </li>
            </ul>
          </div>

          {/* Contacto */}
          <div>
            <h4 className="font-semibold mb-4">Contacto</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>contacto@everywoman.mx</p>
              <p>+52 55 1234 5678</p>
              <p>Ciudad de México, México</p>
            </div>
            <div className="flex gap-3 mt-4">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-border/40 mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2024 Everywoman Joyería. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
