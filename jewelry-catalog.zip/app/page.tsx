"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { Survey } from "@/components/survey"
import { Catalog } from "@/components/catalog"
import { Footer } from "@/components/footer"
import { FeaturedProduct } from "@/components/featured-product"

export default function Home() {
  const [showSurvey, setShowSurvey] = useState(false)
  const [surveyResults, setSurveyResults] = useState<any>(null)
  const [showCatalog, setShowCatalog] = useState(false)

  const handleStartSurvey = () => {
    setShowSurvey(true)
  }

  const handleSurveyComplete = (results: any) => {
    setSurveyResults(results)
    setShowSurvey(false)
    setShowCatalog(true)
  }

  const handleBackToHome = () => {
    setShowSurvey(false)
    setShowCatalog(false)
    setSurveyResults(null)
  }

  return (
    <main className="min-h-screen bg-background">
      <Header onBackToHome={handleBackToHome} showBackButton={showSurvey || showCatalog} />

      {!showSurvey && !showCatalog && (
        <>
          <Hero onStartSurvey={handleStartSurvey} />
          <FeaturedProduct />
        </>
      )}

      {showSurvey && <Survey onComplete={handleSurveyComplete} />}

      {showCatalog && surveyResults && <Catalog surveyResults={surveyResults} />}

      <Footer />
    </main>
  )
}
